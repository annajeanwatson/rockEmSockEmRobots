**To detach a virtual private gateway from your VPC**

This example detaches the specified virtual private gateway from the specified VPC. If the command succeeds, no output is returned.

Command::

  aws ec2 detach-vpn-gateway --vpn-gateway-id vgw-9a4cacf3 --vpc-id vpc-a01106c2
